import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart' as intl;
import 'package:path_provider/path_provider.dart';
import 'package:rowwad/Model/FireBaseCreate.dart';
import 'package:rowwad/Pages/QuestionPage.dart';
import 'package:rowwad/Widgets/ProfileWidgets.dart';

class WelcomeScreen extends StatefulWidget {
  WelcomeScreen({Key key}) : super(key: key);

  @override
  _WelcomeScreenState createState() => _WelcomeScreenState();
}

FireBaseCreate myfireStoreCommand = new FireBaseCreate();
StreamSubscription<QuerySnapshot> lesObjectifs;
String userName;
int position;
int totalBonReponce = 0;
int star;
int manyTime = 1;
double moyen;
String grade;
String firstDate;
String lastDate;
Map data;
File imageFile;
String _url;
String imageUrl;
bool isClicked = false;

class _WelcomeScreenState extends State<WelcomeScreen> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    getApplicationDocumentsDirectory().then((Directory directory) {
      dir = directory;
      jsonFile = File(dir.path + "/" + fileName);
      fileExists = jsonFile.existsSync();

      if (fileExists) {
        this.setState(
            () => fileContent = json.decode(jsonFile.readAsStringSync()));
        userName = fileContent["userName"];
        totalBonReponce = fileContent["totalBonReponce"];
        firstDate = fileContent["firstDate"];
        manyTime = fileContent["manyTime"];
        manyTime == null ? manyTime = 1 : manyTime = fileContent["manyTime"];
        imageUrl = fileContent["imageUrl"];
        print("imageUrl $imageUrl");

        if (fileContent["position"] == null) {
          position = 1;
        } else {
          position = fileContent["position"];
        }
        Future<int> myFuture() async {
          return totalBonReponce = fileContent["totalBonReponce"];
        }

        print("image url $imageUrl");
        myFuture().then((value) {
          myGrade(value);
          if (value == null)
            setState(() {
              totalBonReponce = 0;
            });
        });
        writeToFile("manyTime", manyTime + 1);
      }
      if (totalBonReponce != null && totalBonReponce != 0) {
        moyen = (totalBonReponce.toDouble() / position.toDouble()) * 10;
      }

      DateTime now = DateTime.now();
      lastDate = intl.DateFormat('d/M/y HH:mm').format(now);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomPadding: false,
      key: _scaffoldKey,
      body: Center(
        child: Container(
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("images/profile.jpg"), fit: BoxFit.cover)),
          child: SafeArea(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Expanded(
                child: Builder(
                  builder: (context) => InkWell(
                    onTap: () {
                      isClicked = true;
                      pickImage(false).then((_) {
                        uploadImage(context, userName);
                        writeToFile("imageUrl", imageFile.path);
                      });
                    },
                    onLongPress: () {
                      isClicked = true;
                      pickImage(true).then((_) {
                        uploadImage(context, userName);
                        writeToFile("imageUrl", imageFile.path);
                      });
                    },
                    child: Container(
                      child: profileImage(
                          imageString: !isClicked
                              ? FileImage(File("$imageUrl"))
                              : FileImage(imageFile),
                          name: "$userName",
                          grade: (grade == null) ? "" : "$grade",
                          bonReponce: (totalBonReponce == null)
                              ? "0"
                              : "$totalBonReponce",
                          question: "$position"),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  child: myStatic(
                      firstDate: firstDate,
                      moyen: (totalBonReponce == null)
                          ? "0"
                          : moyen.toStringAsFixed(1) + "/10",
                      classement: 50,
                      star: 10),
                ),
              ),
              RaisedButton(
                color: Colors.blue,
                child: Text(
                  "حسنا",
                  style: TextStyle(fontSize: 22, color: Colors.white),
                ),
                onPressed: () {
                  createData();
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => QuestionPage()),
                  );
                },
              ),
              // SizedBox(height: 10,)
            ],
          )),
        ),
      ),
    );
  }

  void myGrade(int myvalue) {
    if (myvalue > 0 && myvalue < 10)
      setState(() {
        grade = "مبتدئ";
      });
    if (myvalue >= 10 && myvalue < 20)
      setState(() {
        grade = "لا بأس بك";
      });
    if (myvalue >= 20 && myvalue < 30)
      setState(() {
        grade = "عاصرت الجيل الذهبي";
      });
    if (myvalue >= 30 && myvalue < 40)
      setState(() {
        grade = "انت فنان";
      });
    if (myvalue >= 40)
      setState(() {
        grade = "عميد الأغينة المغربية";
      });
  }

  // Method to show snackbar with 'message'.

  createData() {
    DocumentReference ds =
        Firestore.instance.collection('User').document("$userName");
    Map<String, dynamic> tasks = {
      "id": userName,
      "name": userName,
      "firstSingin": firstDate,
      "lastLogin": lastDate,
      "totalQuestion": position,
      "totalGoodQuestion": totalBonReponce,
      "manyTime": manyTime + 1,
      "autre2": "autre 2 vide",
    };

    ds.setData(tasks).whenComplete(() {});

    print("done done");
  }

  Future pickImage(bool camera) async {
    if (camera) {
      File image = await ImagePicker.pickImage(source: ImageSource.camera);
      setState(() {
        imageFile = image;
      });
    } else {
      File image = await ImagePicker.pickImage(source: ImageSource.gallery);
      setState(() {
        imageFile = image;
      });
    }
  }

  void uploadImage(context, String photoName) async {
    try {
      FirebaseStorage firebaseStorage =
          FirebaseStorage(storageBucket: "gs://rowwad-b7c15.appspot.com");
      StorageReference storageReference =
          firebaseStorage.ref().child("$userName.jpg");
      StorageUploadTask storageUploadTask = storageReference.putFile(imageFile);
      StorageTaskSnapshot storageTaskSnapshot =
          await storageUploadTask.onComplete;
      Scaffold.of(context).showSnackBar(SnackBar(
        content: Text(
          "تم تغيير الصورة بنجاح",
          textDirection: TextDirection.rtl,
        ),
      ));
      String url = await storageTaskSnapshot.ref.getDownloadURL();
      setState(() {
        _url = url;
      });
    } catch (ex) {
      print(ex.message);
    }
  }

  void createFile(
      Map<String, dynamic> content, Directory dir, String fileName) {
    print("Creating file!");
    File file = new File(dir.path + "/" + fileName);
    file.createSync();
    fileExists = true;
    file.writeAsStringSync(json.encode(content));
  }

  void writeToFile(String key, dynamic value) {
    print("Writing to file!");
    Map<String, dynamic> content = {key: value};
    if (fileExists) {
      print("File exists");
      Map<String, dynamic> jsonFileContent =
          json.decode(jsonFile.readAsStringSync());
      jsonFileContent.addAll(content);
      jsonFile.writeAsStringSync(json.encode(jsonFileContent));
    } else {
      print("File does not exist!");
      createFile(content, dir, fileName);
    }
    this.setState(() => fileContent = json.decode(jsonFile.readAsStringSync()));
    print(fileContent);
  }
}
